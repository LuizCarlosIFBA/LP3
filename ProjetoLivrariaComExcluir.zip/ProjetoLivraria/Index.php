<?php
     $url = $_GET['url'];
     $url = strtoupper($url);
     echo "URL=",$url,strpos($url,"SALVAR");
     if ($url=="LISTAR"){
        require "Controller/ControladorLivro.php";  
        $controle = new ControladorLivro();
        $controle->processa("L");
     }
     else if ($url=="INCLUIR" || $url=="CADASTRAR")
     {
      require "Controller/ControladorLivro.php";  
      $controle = new ControladorLivro();
      $controle->processa("M");
     }
     else if (strpos($url,"SALVAR")>0){
      require "Controller/ControladorLivro.php";  
      $controle = new ControladorLivro();
      $controle->processa("S");
     }
     else if ($url=="EXCLIVRO"){
      require "Controller/ControladorLivro.php";  
      $controle = new ControladorLivro();
      $controle->processa("E");
     }
     else if ($url=="SALVAUSUARIO"){
      require "Controller/ControladorUsuario.php";  
      $controle = new ControladorUsuario();
      $controle->processa("S");
     }
     else if ($url=="CADUSU"){
      require "Controller/ControladorUsuario.php";  
      $controle = new ControladorUsuario();
      $controle->processa("M");
     }
     else if ($url=="TELALOGIN"){
      require "Controller/ControladorUsuario.php";  
      $controle = new ControladorUsuario();
      $controle->processa("A");
     }
     else if ($url=="LOGAR"){
      require "Controller/ControladorUsuario.php";  
      $controle = new ControladorUsuario();
      $controle->processa("L");
     }
     
?>