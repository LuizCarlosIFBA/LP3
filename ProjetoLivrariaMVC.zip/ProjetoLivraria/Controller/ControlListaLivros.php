<?php 
require_once "Model/Livro.php";
$meuLivro = new Livro("",0,0,0);
$meuLivro->pesqTodos();

require "View/ListaLivros.php";
?>