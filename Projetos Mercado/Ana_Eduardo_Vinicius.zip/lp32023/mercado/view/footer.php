<footer style="margin: auto 0 0 0" class="bg-light text-center text-lg-start footer">
  <div class="text-center p-3">
    © 2023 Mercado. Todos os direitos reservados.
  </div>
</footer>