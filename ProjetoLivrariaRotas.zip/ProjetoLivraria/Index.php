<?php
     $url = $_GET['url'];
     $url = strtoupper($url);
     echo "URL=",$url,strpos($url,"SALVAR");
     if ($url=="LISTAR"){
        require "Controller/ControladorLivro.php";  
        $controle = new ControladorLivro();
        $controle->processa("L");
     }
     else if ($url=="INCLUIR" || $url=="CADASTRAR")
     {
      require "Controller/ControladorLivro.php";  
      $controle = new ControladorLivro();
      $controle->processa("M");
     }
     else if (strpos($url,"SALVAR")>0){
      require "Controller/ControladorLivro.php";  
      $controle = new ControladorLivro();
      $controle->processa("S");
     }
?>