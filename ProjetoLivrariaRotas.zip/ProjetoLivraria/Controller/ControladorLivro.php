<?php

class ControladorLivro{

    public function processa($acao){
        if ($acao=="L"){
          require_once "Model/Livro.php";
          $meuLivro = new Livro("",0,0,0);
          $meuLivro->pesqTodos();
          require "View/ListaLivros.php";
        }
        else if($acao=="S"){
            require_once "Model/Livro.php";
            $meuLivro = new Livro($_POST['titulo'],$_POST['edicao'],$_POST['ano'],$_POST['preco']);
            $meuLivro->incluir();
        }
        else
           require "View/CadLivro.php"; 
    }
}

?>