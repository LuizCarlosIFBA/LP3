<?php
     $url = $_GET['url'];
     $url = strtoupper($url);
     if ($url=="LISTAR")
        require "Controller/ControlListaLivros.php";  
     else if ($url=="INCLUIR" || $url=="CADASTRAR")
        require "View/CadLivro.php";  
     else
        require "Controller/ControlListaLivros.php";  
?>