<?php
require_once "Model/Banco.php";
class Usuario{
    private $id;
    private $nome;
    private $email;
    private $senha;
    

    public function setId($id){
        $this->id = $id;
    }
    public function setNome($nome){
        $this->nome=$nome;
    }
    public function setEmail($email){
        $this->email = $email;
    }
    public function setSenha($senha){
        $this->senha = $senha;
    }
    public function getId(){
        return $this->id;
    }
    public function getNome(){
        return $this->nome;
    }
    public function getEmail(){
        return $this->email;
    }
    public function getSenha(){
        return $this->senha;
    }

    public function incluir(){
        
        try
        {
        $conn = Banco::conectar();
        $sql = $conn->prepare ("insert into bd_livraria.usuario (nome, email, senha)
        values (:nome, :email, :senha)");
        $sql->bindParam("nome",$nome);
        $sql->bindParam("email",$email);
        $sql->bindParam("senha",$senha);

        $nome = $this->nome;
        $email = $this->email;
        $senha = $this->senha;

       $sql->execute();
       echo "inserido com sucesso";
       }
       catch(PDOException $e)
        {
        echo "Connection failed: ". $e->getMessage();
        }
    }

    public function verificaLogin(){
        
        try
        {
        $conn = Banco::conectar();
        $sql = $conn->prepare ("select * from bd_livraria.usuario where nome=:nome and senha=:senha ");
        
        $sql->bindParam("nome",$nome);
        $sql->bindParam("senha",$senha);

        $nome = $this->nome;
        $senha = $this->senha;

       $sql->execute();
       $result=$sql->setFetchMode(PDO::FETCH_ASSOC);
        $achou=false;
        while ($linha = $sql->fetch(PDO::FETCH_ASSOC))
         {
          $achou=true;
         }
         if ($achou)
            return true;
        else
            return false;
       }
       catch(PDOException $e)
        {
        echo "Connection failed: ". $e->getMessage();
        return false;
        }
    }

}

?>