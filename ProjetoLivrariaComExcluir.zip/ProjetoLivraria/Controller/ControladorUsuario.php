<?php
session_start();
class ControladorUsuario{
    public function processa($acao){
        if ($acao=="S"){
            require_once "Model/Usuario.php";
            $usu = new Usuario();
            $usu->setNome($_POST['nome']);
            $usu->setEmail($_POST['email']);
            $usu->setSenha($_POST['senha']);
            $usu->incluir();
        }
        else if ($acao=="A")
            require_once "View/Login.php";
        else if ($acao=="L")
           {
            require_once "Model/Usuario.php";
            $usu = new Usuario();
            $usu->setNome($_POST['nome']);
            $usu->setSenha($_POST['senha']);
            $resposta = $usu->verificaLogin();
            if ($resposta)
              {
                $_SESSION['usuario'] = $usu;
              }
           }
        else{
            require_once "View/CadUsuario.php";
        }
    }

}
?>